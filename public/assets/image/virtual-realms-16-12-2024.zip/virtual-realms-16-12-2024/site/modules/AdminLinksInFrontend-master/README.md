# AdminLinksInFrontend
A ProcessWire module that displays configurable Adminlinks on the frontpage

Read more about it in the Supportforum: https://processwire.com/talk/topic/11666-alif-admin-links-in-frontend/

Credits for the JavaScript Color Picker goes to: Jan Odvarko (http://jscolor.com)
