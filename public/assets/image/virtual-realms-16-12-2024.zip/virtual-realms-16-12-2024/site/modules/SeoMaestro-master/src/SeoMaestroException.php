<?php

namespace SeoMaestro;

use ProcessWire\WireException;

class SeoMaestroException extends WireException
{
}
